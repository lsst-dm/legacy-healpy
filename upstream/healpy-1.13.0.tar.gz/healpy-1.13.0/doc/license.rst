********
Licenses
********

Healpy License
==============

Healpy is licensed under the GNU General Public License.

.. include:: ../COPYING
