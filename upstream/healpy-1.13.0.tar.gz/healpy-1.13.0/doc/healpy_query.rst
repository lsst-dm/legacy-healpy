.. currentmodule:: healpy


Pixel querying routines
=======================

.. autosummary::
   :toctree: generated/

   query_disc
   query_polygon
   query_strip
   boundaries
